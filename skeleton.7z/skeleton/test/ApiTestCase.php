<?php
declare(strict_types=1);

namespace Test;

/**
 * Class TestCase de base pour les tests du projet
 */
class ApiTestCase extends ControllerTestCase
{

}
